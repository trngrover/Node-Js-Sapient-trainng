var x = 100, 
	y = 50;

var calculator = require('./calculator.js');
console.log(calculator.add(x,y));
console.log(calculator.subtract(x,y));
console.log(calculator.multiply(x,y));
console.log(calculator.divide(x,y));